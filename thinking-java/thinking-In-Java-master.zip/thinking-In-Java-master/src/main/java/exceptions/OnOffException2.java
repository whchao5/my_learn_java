//: exceptions/OnOffException2.java
package exceptions; /* Added by Eclipse.py */
public class OnOffException2 extends Exception {} ///:~
