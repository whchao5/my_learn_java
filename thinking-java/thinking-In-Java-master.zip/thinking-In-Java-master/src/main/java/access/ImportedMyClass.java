//: access/ImportedMyClass.java
package access; /* Added by Eclipse.py */
import access.mypackage.*;

public class ImportedMyClass {
  public static void main(String[] args) {
    MyClass m = new MyClass();
  }
} ///:~
