//: access/QualifiedMyClass.java
package access; /* Added by Eclipse.py */

public class QualifiedMyClass {
  public static void main(String[] args) {
    access.mypackage.MyClass m =
      new access.mypackage.MyClass();
  }
} ///:~
