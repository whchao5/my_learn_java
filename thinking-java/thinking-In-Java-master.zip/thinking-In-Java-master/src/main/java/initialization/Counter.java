//: initialization/Counter.java
package initialization; /* Added by Eclipse.py */
public class Counter {
  int i;
  Counter() { i = 7; }
  // ...
} ///:~
