//: initialization/Apricot.java
package initialization; /* Added by Eclipse.py */
public class Apricot {
  void pick() { /* ... */ }
  void pit() { pick(); /* ... */ }
} ///:~
