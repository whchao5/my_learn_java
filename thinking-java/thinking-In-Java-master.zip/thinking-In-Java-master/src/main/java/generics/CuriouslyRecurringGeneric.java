//: generics/CuriouslyRecurringGeneric.java
package generics; /* Added by Eclipse.py */

class GenericType<T> {}

public class CuriouslyRecurringGeneric
  extends GenericType<CuriouslyRecurringGeneric> {} ///:~
