//: generics/coffee/Latte.java
package generics.coffee;
public class Latte extends Coffee {} ///:~
