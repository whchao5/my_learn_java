//: generics/ArrayOfGenericReference.java
package generics; /* Added by Eclipse.py */

class Generic<T> {}

public class ArrayOfGenericReference {
  static Generic<Integer>[] gia;
} ///:~
