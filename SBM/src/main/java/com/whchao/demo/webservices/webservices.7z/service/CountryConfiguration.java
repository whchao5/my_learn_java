package com.whchao.demo.webservices.service;

public class CountryConfiguration {
}
